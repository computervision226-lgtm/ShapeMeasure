ShapeMeasure export

Keep each .shp/.shx/.dbf/.prj/.cpg set together. All coordinates use local metres; Z is up.
These files are not positioned on Earth. Do not assign EPSG:4326 or another geographic CRS.

footprint.shp: 2D clockwise convex hull of the object. Open this layer first in QGIS.
mesh.shp: true 3D MultiPatch triangle fans, including vertical faces. View in a compatible
3D GIS viewer, such as an ArcGIS Pro local scene. Reader support for MultiPatch varies.
measures.shp: PolyLineZ bounds and saved straight point-to-point measurements.
model.obj: calibrated geometry in the same local Z-up metric frame.
report.json: full metrics, scale provenance, topology and interpretation.
measurements.csv: lengths in metres, not distances along the surface.

Object bounding dimensions follow the reconstructed model axes. They are not an oriented
minimum bounding box. Footprint area includes concave voids. Surface area measures the
reconstructed mesh and may include artifacts. Volume is blank/null unless a single closed
consistently oriented component is found; self-intersection is not checked. Validate all
important measurements against a ruler. LiDAR-assisted scale is an estimate. REFERENCE
means the user set scale using a known length. DEMO means synthetic sample geometry.
